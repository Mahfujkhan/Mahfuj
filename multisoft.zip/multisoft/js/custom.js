$(document).ready(function(){

	$('.carousel').carousel({
		interval: 2000
	  })

	// Scroll bottom
	$('.top_up_bottom a').click(function(){

		$('html, body').animate({'scrollTop': 0},2000);

		return false;

	});

	$(window).scroll(function () { 
		if($(window).scrollTop() > 1900){

		$('.top_up_bottom a').fadeIn(2000);

		}else{
		$('.top_up_bottom a').fadeOut(2000);
		}

	});

	// Nav bar Show Hide

	$('.navbar-toggler').click(function(){

		$('.navbar-collapse').slideToggle();

		return false;

	});


		// preloader
	
	$(window).load('on', function() { // makes sure the whole site is loaded 
		$('#status').fadeOut(); // will first fade out the loading animation 
		$('#preloader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website. 
		$('body').delay(350).css({'overflow':'visible'});
	})
		
});

// CountDown

// Set the date we're counting down to
var countDownDate = new Date("Jan 5, 2021 15:37:25").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("sec").innerHTML = seconds+ '<span style="font-size: 17px; font-weight:200;"> Sec</span>';
  document.getElementById("min").innerHTML = minutes+ '<span style="font-size: 17px; font-weight:200;"> Min</span>';
  document.getElementById("hours").innerHTML = hours+ '<span style="font-size: 17px; font-weight:200;"> Hours</span>';
  document.getElementById("days").innerHTML = hours+ '<span style="font-size: 17px; font-weight:200;"> Days</span>';


  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("sec").innerHTML = "EXPIRED";
    document.getElementById("min").innerHTML = "EXPIRED";
    document.getElementById("hours").innerHTML = "EXPIRED";
    document.getElementById("days").innerHTML = "EXPIRED";
  
  }
}, 1000);


// Copyright 
var copyRight = 'Copyright ©2019 All rights reserved | This template is made with by <a href="http://www.facebook.com/mafuj.khan" target="_blank">Mahfuj Khan,</a> Student Multisoft IT, Web Design Batch-1969';

document.getElementById('copyright').innerHTML=copyRight;



// Modal box

var mainImg = document.querySelectorAll('.modal_img');
var modalImg = document.querySelector('.modal_img_main');
var close = document.querySelector('.close_modal');

for (let i = 0; i < mainImg.length; i++) {

	mainImg[i].addEventListener('click', function() {
		document.getElementById('modal_box').style.display = 'block';
		modalImg.src = mainImg[i].src;
	});
};
close.addEventListener('click', function () {
	document.getElementById('modal_box').style.display = 'none';
	
});


