<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>MultiSoft It</title>
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="../css/style.css" media="all" />
		<link rel="stylesheet" type="text/css" href="../css/responsive.css" media="all" />
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css" media="all" />
		<link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css" media="all" />
		<link rel="stylesheet" type="text/css" href="../css/dropdownmenu.css" media="all" />
	</head>
	<body>

		<!--Top up bottom-->

		<div class="top_up_bottom">
			<a href="#"><i class="fa fa-chevron-up"></i></a>
		</div>

			<!-- Preloader Started From Here -->
		
		<div id="preloader">
			<div id="status">&nbsp;</div>
		</div>
			
			<!-- Preloader End From Here -->
			<!--Contacts Area Started From Here  -->

		<section class="container-fluid contacts_area py-2">		
			<div class="row text-white">
				<div class="col-lg-4 r_p">
					<div class="d-flex">
						<span style="background-color: red;" ><i class="fa fa-phone"></i></span>
						<h5 class="pl-2">+88 01717063191, +88 01302064001 </h5>
					</div>
				</div>
				<div class="col-lg-3 r_p">
					<div class="d-flex justify-content-center">
						<span style="background-color: #FDA638;" ><i class="fa fa-envelope"  ></i></span>
						<h5 class="pl-2">multisoft18@gmail.com</h5>
					</div>
				</div>
				<div class="col-lg-5 r_p">
					<div class="d-flex justify-content-end ">
						<span style="background-color: #5D50C6;"><i class="fa fa-home"></i></span>
						<h5 class="pl-2">Feni Supper Market, 3rd floor, Trunk Road, Feni-3900.</h5>
					</div>
				</div> 
			</div>		
		</section>		
	
			<!-- Contacts Area End From Here  -->
			<!--Header Area Started From Here-->		

		<section class="container-fluid header_area ">
			<div class="row align">
				<div class="col-sm-4 logo">
					<div class="logo_area">
						<img class="img-fluid" src="img/mit-logo.png" alt="MultiSoft icon" />
					</div>
				</div>
				<div class="col-sm-8">
					<div class="logo_area_side">
						<img class="img-fluid" src="img/topbanner.jpg" alt="Multi soft Banner">
					</div>
				</div>
			</div>
		</section>

			<!--Header Area bottom End From Here-->
			<!--Menu Area Started From Here-->

		<section class="container-fluid menu_area py-2">
			<div class="container r_m1">
				<nav class="navbar navbar-expand-lg r_m ">
					<button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbar">
						<span class="text-white"><i class="fa fa-navicon"></i></span>
					</button>
					<div class="collapse navbar-collapse " id="navbar">
						<ul class="my-2">
							<li><a class="home" href="../index.html">Home</a></li>
							<li><a class="m_a_l_about_us" href="#">About us</a>
						<ul class="about_mit">
							<li><a href="../about us/aboutmit.html">About mit</a></li>
							<li><a href="../about us/the_ceo.html">the CEO message</a></li>
						</ul>
							</li>
							<li><a href="../course.html">Course</a></li>
							<li><a href="../service.html">Service</a></li>
							<li><a href="../gallery.html">Gallery</a></li>
							<li><a class="student" href="#student">Student</a>
						<ul>
							<li><a href="../student/student.html">Student info</a></li>
							<li><a href="#">Student Highlight</a></li>
						</ul>
							</li>
								<li><a href="../cotacts.html">Contact</a></li>
						</ul>	
						<a class="btn btn-primary ml-auto mr-3" href="../login-singup/login.html">Login</a>
						<span><a class="btn btn-primary" href="../login-singup/singup.html">Sing up</a></span>									
					</div>
				</nav> 
			</div>
		</section>

			<!--Menu Area End From Here-->				
			<!--Sing up Started  Header Area-->
		
		<div class="row">
			<div class="col-md-12 bg-dark text-white py-5 ">
				<h2 class="text-center text-uppercase ">Sing up</h2>
			</div>
		</div>
	
			<!-- start -->

		<section class="container my-3">
			<form action="../login-singup/singup.php" method="post" enctype="multipart/form-data">
				<div class="row my-2">
					<div class="col-md-8">
						<input class="form-control" type="text" name="name" placeholder="Name">
					</div>
					<div class="col-md-4">
						<input class="form-control" type="tel" name="u_cell" placeholder="Cell">
					</div>
				</div>
				<div class="row my-2">
					<div class="col-md-8">
						<input class="form-control" type="text" name="f_name" placeholder="Father Name">
					</div>
					<div class="col-md-4">
						<input class="form-control" type="tel" name="f_cell" placeholder="Cell">
					</div>
				</div>
				<div class="row my-2">
					<div class="col-md-8">
						<input class="form-control" type="text" name="m_name" placeholder="Mother Name">
					</div>
					<div class="col-md-4">
						<input class="form-control" type="tel" name="m_cell" placeholder="Cell">
					</div>
				</div>
				<div class="row my-2">
					<div class="col-md-12">
						<input class="form-control"  type="email" name="email" placeholder="Email Address">
					</div>
				</div>
				<div class="row my-2">
					<div class="col-md-12">
						<input class="form-control"  type="password" name="password" placeholder="Password">
					</div>
				</div>
				<div class="row my-2">
					<div class="col-md-12">
						<input class="form-control" type="text" name="p_address" placeholder="Permanent Address">
					</div>
					<div class="col-md-12 my-1">
						<input class="form-control" type="text" name="p2_address" placeholder="">
					</div>
				</div>
				<div class="row my-2">
					<div class="col-md-12">
						<input class="form-control" type="url" name="fb_link" placeholder="FB link">
					</div>
				</div>
				<div class="row my-2">
					<div class="col-md-12">
						<input class="form-control" type="tel" name="nid_no" placeholder="NID No">
					</div>
				</div>
				<div class="row my-2">
					<div class="col-md-12">
						<input class="form-control" type="text" name="occupation" placeholder="Occupation">
					</div>
				</div>
				<div class="row my-2">
					<div class="col-md-8">
						<input class="form-control" type="text" name="nationality" placeholder="Nationality">
					</div>
					<div class="col-md-4">
						<input class="form-control" type="text" name="religions" placeholder="Religions">
					</div>
				</div>
				<div class="row my-2">
					<div class="col-md-6">
						<input class="form-control" type="text" name="institute" placeholder="Institute Name">
					</div>
					<div class="col-md-3">
						<input class="form-control" type="text" name="class" placeholder="Class">
					</div>
					<div class="col-md-3">
						<input class="form-control" type="tel" name="id_no" placeholder="ID No">
					</div>
				</div>
				<div class="row my-2">
					<div class="col-md-12">
						<input class="form-control" type="text" name="course" placeholder="Course Name">
					</div>
					<div class="col-md-12 my-3">
						<input class="" type="file" name="up_photo">
					</div>
				</div>				
				<div class="row my-2 justify-content-center">
					<div class="col-md-4 ">
						<input class="form-control btn btn-warning" type="submit" value="Submit">
					</div>
				</div>
			</form>
		</section>
				
			<!-- Reg Area End Here -->

<?php

if (isset($_POST['name'])) {
	
	echo $_POST['name'].'<br>';      
	echo $_POST['u_cell'].'<br>';      
	echo $_POST['f_name'].'<br>';      
	echo $_POST['f_cell'].'<br>';     
	echo $_POST['m_name'].'<br>';     
	echo $_POST['m_cell'].'<br>';     
	echo $_POST['email'].'<br>';     
	echo $_POST['password'].'<br>';     
	echo $_POST['p_address'].'<br>';     
	echo $_POST['p2_address'].'<br>';     
	echo $_POST['fb_link'].'<br>';    
	echo $_POST['nid_no'].'<br>';
	echo $_POST['occupation'].'<br>';     
	echo $_POST['nationality'].'<br>';     
	echo $_POST['religions'].'<br>';     
	echo $_POST['institute'].'<br>';     
	echo $_POST['class'].'<br>';     
	echo $_POST['id_no'].'<br>';     
	echo $_POST['course'].'<br>';     
	echo $_POST['up_photo'].'<br>';    


} 





?>



			<!-- sing up area -->
		<!-- Contact form Area Started From Here -->

		<section class="container-fluid contact_f ">
			<div class="container">
					<div class="row title_1 text-center pt-4 ">
						<h2 class="col-12 py-2 text-white">MultiSoft Institute of Technology</h2>
						<p class="col-12 my-2 text-light">With The Promise Of Change</p>
					</div>	
					<div class="py-3"></div>
				<div class="row justify-content-lg-around py-5">
					<div class="col-md-4 my-2 ">
						<div class="d-flex justify-content-around bg-white py-2">
							<span class="mt-4 pl-4" ><i class="fa fa-phone"></i></span>
							<div class="text-center">
								<h4>Please feel for any asking...</h4>
								<p >+88 01717063191 <br>+88 01302064001</p>
							</div>
						</div>
					</div>
					<div class="col-md-4 my-2">
						<div class="d-flex justify-content-around bg-white py-2">
							<span class=""><i class="fa fa-envelope"></i></span>
							<div>
								<h4>Send us a mail:</h4>
								<p> multisoft18@gmail.com</p>
							</div>
						</div>
					</div>
					<div class="col-md-4 my-2  ">
						<div class="d-flex justify-content-around bg-white py-2">
							<span class=""><i class="fa fa-map-marker"></i></span>
							<div>
								<h4>Come visit us:</h4>
								<p>Directions to <span>our location</span> </p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>                                   
	
			<!-- Contact form Area End From Here -->
			<!-- Footer Area Started From Here -->

		<footer class="container-fluid footer_area py-5">		
			<div class="row justify-content-around ">
				<div class="col-lg-4 my-3" >
					<img src="img/mit_mainu.png" class="img-fluid" alt="multi soft icon">
					<div class="social_link my-3 text-center">
						<a href="#"><i class="fa fa-facebook" style="background: #4F689E;"></i></a>
						<a href="#"><i class="fa fa-twitter" style="background:#74C7D5;"></i></a>
						<a href="#"><i class="fa fa-google-plus" style="background:#DF5B66;"></i></a>
						<a href="#"><i class="fa fa-linkedin" style="background:#3E62B0;"></i></a>
					</div>
				</div>				
				<div class="col-lg-4 my-2">
					<div class="f_a_item text-right">
						<h3>Newsletter</h3>
						<p>You can trust us. we only send promo offers,</p>
						<div class="d-flex my-4">
							<input type="email" class="form-control ml-5" required name="email" placeholder="Your Email Address">
							<button type="submit" class="btn btn-primary" value="Subcribe">Subscribe</button>
						</div>
					</div>
				</div>
			</div>
			<div class="row justify-content-center text-center my-3">
			<p class="text-dark" id="copyright"></p>
			</div>			
		</footer>

			<!-- Footer Area End From Here -->

		<script src="../js/bootstrap.bundle.min.js"></script>
		<script src="../js/juquary_min.js"></script>
		<script src="../js/custom.js"></script>

		
	
	</body>

</html>
